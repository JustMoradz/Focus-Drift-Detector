let tabSwitchCount = 0;
let lastSwitchTime = Date.now();
chrome.tabs.onActivated.addListener(() => {
tabSwitchCount++;
});
setInterval(() => {
const now = Date.now();
const timeElapsed = (now - lastSwitchTime) / 1000;
chrome.storage.local.set({
tabSwitchRate: tabSwitchCount / Math.max(timeElapsed,1)
});
tabSwitchCount = 0;
lastSwitchTime = now;
}, 10000);