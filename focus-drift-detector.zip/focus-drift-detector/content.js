let scrollSamples = [];
let mouseSamples = [];
function variance(arr) {
if (arr.length === 0) return 0;
const mean = arr.reduce((a,b)=>a+b,0)/arr.length;
return arr.reduce((a,b)=>a+Math.pow(b-mean,2),0)/arr.length;
}
let lastScroll = 0;
window.addEventListener("scroll", () => {
const now = window.scrollY;
scrollSamples.push(Math.abs(now - lastScroll));
lastScroll = now;
});
window.addEventListener("mousemove", (e) => {
mouseSamples.push(Math.sqrt(e.movementX**2 + e.movementY**2));
});
function showWidget(score) {
let widget = document.getElementById("focus-widget");
if (!widget) {
widget = document.createElement("div");
widget.id = "focus-widget";
document.body.appendChild(widget);
}
widget.innerHTML = `<strong>Focus Stability:</strong> ${score.toFixed(2)}
`;
if (score > 0.7) widget.style.background = "#2ecc71";
else if (score > 0.4) widget.style.background = "#f1c40f";
else widget.style.background = "#e74c3c";
}
setInterval(() => {
const scrollVar = variance(scrollSamples);
const mouseVar = variance(mouseSamples);
chrome.storage.local.get(["tabSwitchRate"], (data) => {
const ts = data.tabSwitchRate || 0;
const focusScore = Math.exp(-(0.5*ts + 0.3*scrollVar +
0.2*mouseVar));
chrome.storage.local.set({ focusScore });
showWidget(focusScore);
});
scrollSamples = [];
mouseSamples = [];
}, 2000); // aggiorna più spesso