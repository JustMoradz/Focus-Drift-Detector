const scoreEl = document.getElementById("score");
const statusEl = document.getElementById("status");
function updateUI(score) {
scoreEl.innerText = score.toFixed(2);
if (score > 0.7) {
statusEl.style.background = "#2ecc71";
statusEl.innerText = "Deep Focus";
} else if (score > 0.4) {
statusEl.style.background = "#f1c40f";
statusEl.innerText = "Stable";
} else {
statusEl.style.background = "#e74c3c";
statusEl.innerText = "Drift Detected";
}
}
// iniziale
chrome.storage.local.get(["focusScore"], (data) => {
const score = data.focusScore || 1;
updateUI(score);
});
// aggiornamento live
chrome.storage.onChanged.addListener((changes, area) => {
if (changes.focusScore) {
updateUI(changes.focusScore.newValue);
